﻿using System.IO;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace Os
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }

        public class TranslationFilter : MemoryStream
        {
            private Stream filter = null;

            public TranslationFilter(HttpResponseBase httpResponseBase)
            {
                filter = httpResponseBase.Filter;
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                var response = UTF8Encoding.UTF8.GetString(buffer);

                //remove all newlines - minify html on public
                response = response.Replace(System.Environment.NewLine, "");

                //filter.Write(UTF8Encoding.UTF8.GetBytes(response), offset, UTF8Encoding.UTF8.GetByteCount(response));
                filter.Write(UTF8Encoding.UTF8.GetBytes(response), offset, UTF8Encoding.UTF8.GetByteCount(response));


            }
        }

        public class ResponseFilter : ActionFilterAttribute
        {
            public ResponseFilter()
            {
            }

            public override void OnResultExecuted(ResultExecutedContext filterContext)
            {
                base.OnResultExecuted(filterContext);

                //minify html on public
                //filterContext.HttpContext.Response.Filter = new TranslationFilter(filterContext.HttpContext.Response);
            }
        }

    }
}
