﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Os
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.RouteExistingFiles = true;
            //routes.IgnoreRoute("hello.html"); //ignore the specific HTML start page
            //routes.IgnoreRoute(""); //to ignore any default root requests

            //admin
            routes.MapRoute(
                name: "collection",
                url: "collection/index",
                defaults: new { controller = "Collection", action = "Index"}
            );
            routes.MapRoute(
                name: "category",
                url: "category/index",
                defaults: new { controller = "Category", action = "Index", alias = UrlParameter.Optional }
            );
            routes.MapRoute(
                name: "category-create",
                url: "category/create",
                defaults: new { controller = "Category", action = "Create", alias = UrlParameter.Optional }
            );
            /*routes.MapRoute(
                name: "category-delete",
                url: "category/delete/{Id}",
                defaults: new { controller = "Category", action = "Delete", Id = UrlParameter.Optional }
            );*/
            routes.MapRoute(
                name: "category-delete",
                url: "category/delete_ajax",
                defaults: new { controller = "Category", action = "Delete_Ajax", Id = UrlParameter.Optional }
            );
            routes.MapRoute(
                name: "category-edit",
                url: "category/edit/{Id}",
                defaults: new { controller = "Category", action = "Edit", Id = UrlParameter.Optional }
            );
            routes.MapRoute(
                name: "article",
                url: "article/index",
                defaults: new { controller = "Article", action = "Index", alias = UrlParameter.Optional }
            );
            routes.MapRoute(
                name: "article-create",
                url: "article/create",
                defaults: new { controller = "Article", action = "Create", alias = UrlParameter.Optional }
            );
            routes.MapRoute(
                name: "article-edit",
                url: "article/edit/{Id}",
                defaults: new { controller = "Article", action = "Edit", Id = UrlParameter.Optional }
            );
            routes.MapRoute(
                name: "article-delete",
                url: "article/delete_ajax",
                defaults: new { controller = "Article", action = "delete_ajax", alias = UrlParameter.Optional }
            );
            //product-hot-list
            routes.MapRoute(
                name: "product-new",
                url: "san-pham-moi",
                defaults: new { controller = "Product", action = "ProductHotList", type = "IsNew" }
            );
            routes.MapRoute(
                name: "product-hot",
                url: "san-pham-hot",
                defaults: new { controller = "Product", action = "ProductHotList", type = "IsHot" }
            );
            routes.MapRoute(
                name: "product-bestsale",
                url: "san-pham-ban-chay",
                defaults: new { controller = "Product", action = "ProductHotList", type = "IsBestSale" }
            );
            routes.MapRoute(
                name: "product-saleoff",
                url: "san-pham-xa-hang",
                defaults: new { controller = "Product", action = "ProductHotList", type = "IsSaleOff" }
            );
            //collection-list
            routes.MapRoute(
                name: "collection-list",
                url: "collect/{alias}",
                defaults: new { controller = "Collection", action = "CollectionList", alias = UrlParameter.Optional }
            );
            //product-list
            routes.MapRoute(
                name: "product-list",
                url: "category/{Tag}",
                defaults: new { controller = "Product", action = "ProductList", Tag = UrlParameter.Optional }
            );
            //product-search
            routes.MapRoute(
                name: "product-search",
                url: "tim",
                defaults: new { controller = "Product", action = "ProductSearch", keyword = UrlParameter.Optional }
            );
            //product-detail
            routes.MapRoute(
                name: "product",
                url: "{Tag}-pro{Id}",
                defaults: new { controller = "Product", action = "ProductDetail", Tag = UrlParameter.Optional, Id = UrlParameter.Optional }
            );
            //article-home
            routes.MapRoute(
                name: "article-home",
                url: "tin-tuc",
                defaults: new { controller = "Article", action = "ArticleHome"}
            );
            //article-list
            routes.MapRoute(
                name: "article-list",
                url: "article/{Tag}",
                defaults: new { controller = "Article", action = "ArticleList", Tag = UrlParameter.Optional }
            );
            //article-search
            routes.MapRoute(
                name: "article-search",
                url: "search",
                defaults: new { controller = "Article", action = "ArticleSearch", keyword = UrlParameter.Optional }
            );
            //article-detail
            routes.MapRoute(
                name: "article-detail",
                url: "{Tag}-art{Id}",
                defaults: new { controller = "Article", action = "ArticleDetail", Tag = UrlParameter.Optional, Id = UrlParameter.Optional }
            );
            
            //about
            routes.MapRoute(
                name: "about",
                url: "gioi-thieu",
                defaults: new { controller = "About", action = "Index"}
            );
            //contact
            routes.MapRoute(
                name: "contact",
                url: "lien-he",
                defaults: new { controller = "Contact", action = "Home" }
            );
            //static-page
            routes.MapRoute(
                name: "static-page",
                url: "page/{alias}",
                defaults: new { controller = "Content", action = "ContentDetail", alias = UrlParameter.Optional }
            );
            //sitemap
            routes.MapRoute(
                name: "sitemap",
                url: "sitemap",
                defaults: new { controller = "SiteMap", action = "Index"}
            );
            routes.MapRoute(
                name: "sitemap-xml",
                url: "sitemap-xml",
                defaults: new { controller = "SiteMap", action = "IndexXML" }
            );
            //rss
            routes.MapRoute(
                name: "product-rss",
                url: "product-rss",
                defaults: new { controller = "SiteMap", action = "ProductXML" }
            );
            routes.MapRoute(
                name: "article-rss",
                url: "article-rss",
                defaults: new { controller = "SiteMap", action = "ArticleXML" }
            );
            //customer
            routes.MapRoute(
                name: "customer-register",
                url: "dang-ky",
                defaults: new { controller = "Customer", action = "CustomerRegister" }
            );
            routes.MapRoute(
                name: "customer-login",
                url: "dang-nhap",
                defaults: new { controller = "Customer", action = "CustomerLogin" }
            );
            routes.MapRoute(
                name: "customer-account",
                url: "taikhoan",
                defaults: new { controller = "Customer", action = "CustomerAccount" }
            );
            //cart
            routes.MapRoute(
                name: "gio-hang",
                url: "gio-hang",
                defaults: new { controller = "ShoppingCart", action = "Index" }
            );
            //gallery
            routes.MapRoute(
                name: "gallery",
                url: "gallery",
                defaults: new { controller = "Album", action = "AlbumHome" }
            );
            //gallery-list
            routes.MapRoute(
                name: "gallery-list",
                url: "gallery/{Id}",
                defaults: new { controller = "Album", action = "AlbumList", Id = UrlParameter.Optional }
            );
            //videos
            routes.MapRoute(
                name: "videos",
                url: "videos",
                defaults: new { controller = "Company", action = "CompanyList" }
            );
            //default
            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
            //

        }
    }
}